# RUN COMMAND: python main.py ./Project-1-Files/CGMData.csv ./Project-1-Files/InsulinData.csv

# main.py
import sys
import numpy as np
import pandas as pd
import sklearn
from sklearn.model_selection import train_test_split
from sklearn import svm
from sklearn.model_selection import cross_val_score
import pickle

# define functions for getting train data
# MD - Meal Data and DT - Date_Time
# passes the insulinData to find valid meal DateTimes
def extractMDDT(ins_extrct_DT):
    # create condition to check non-NaN, non-Zero carb input values
    carbInputCond = ~ins_extrct_DT['BWZ Carb Input (grams)'].isna() & ins_extrct_DT['BWZ Carb Input (grams)']!=0
    # select those Date_Times
    insCarbDT = ins_extrct_DT[carbInputCond].copy(deep=True)
    
    # the latest date_time value is considered MEAL DATA
    # later we can check if the amount of data in this period is <80% then remove
    # else we keep it
    DT_max_2h1m = max(insCarbDT['Date_Time']) + pd.DateOffset(hours=2, minutes=1)
    
    # create columns for next Date_TIME(DT) and DT+2hrs
    insCarbDT['Next_DT'] = insCarbDT['Date_Time'].shift(1, fill_value=DT_max_2h1m)
    insCarbDT['DT+2hrs'] = insCarbDT['Date_Time'] + pd.DateOffset(hours=2)
    
    # conddition to check if Next_DT is between DT and DT+2hrs
    btw2HrsCond = insCarbDT['Next_DT'].between(insCarbDT['Date_Time'], insCarbDT['DT+2hrs'], inclusive='neither')
    insCond2DT = insCarbDT.loc[~btw2HrsCond]
    
    # because we set the between function to have inclusive = 'neither' it keeps cond 3 true
    # Now, only extract the Date_Time values
    insValDT = insCond2DT.loc[:, ['Date_Time']]
    
    return insValDT

def getMDFeatMat(insValDT_, cgmDataPat_, threshold):
    # for each of valid Date_time get corresponding CGM DT after (but earliest) time
    cgmValDT = insValDT_['Date_Time'].apply( lambda x: cgmDataPat_[cgmDataPat_['Date_Time'] >= x]['Date_Time'].min() )
    
    cgmDataList = []
    lengthsList = []
    
    for (ind, val) in cgmValDT.iloc[::-1].iteritems():
        # different masks give different possible lengths of sensor values
        # the chosen mask exclude the time exactly at tm+2hrs (gives more samples to train)
        mask = (cgmDataPat_['Date_Time'] >= val-pd.DateOffset(minutes=30)) & (cgmDataPat_['Date_Time'] < val+pd.DateOffset(hours=2))
        sens_vals = np.array(cgmDataPat_.loc[mask]['Sensor Glucose (mg/dL)'].iloc[::-1])
        
        nonNALen = np.count_nonzero(~np.isnan(sens_vals))
        
        # we only want the data if the non-NaN is 80% or more of 30 (>=24)
        # AND also the length of data is 30
        if (len(sens_vals)==30 and nonNALen >= (threshold/100)*30):
            cgmDataList.append( sens_vals )
            lengthsList.append( nonNALen )
            
    cgmDataList = np.vstack(cgmDataList)
    return {'ft_mat': cgmDataList, 'lengths': lengthsList, 'cgmValDT':cgmValDT}

# function to extract No Meal Data feature matrix
# NMD for No Meal Data
def getNMDFeatMat(cgmVal_, cgmDataPat_, threshold):
    # get the max DT for the cgmData of each patient
    cgmMaxDT = cgmDataPat_['Date_Time'].max()
    
    # reverse the series values (chrono order)
    cgmVal_ = cgmVal_[::-1]
    
    # add maximum DT to the series
    cgmVal_ = cgmVal_.append(pd.Series(cgmMaxDT), ignore_index=True)
    
    # variable storing list of lists of CGM values of No Meal Data
    cgmNMDataList = []
    
    # loop through the valid Meal DTs in cgmVal
    # start from 2hrs after a meal (i.e. at cgmVal_[1])
    for ind, val in cgmVal_[1:-1].iteritems():
        # MDT = Meal DateTime
        cur_MDT = val
        cur_MDT_2h = cur_MDT + pd.DateOffset(hours=2)
        next_MDT = cgmVal_[ind+1]
        # loop to get multiple 2hrs intervals
        # start loop at cur_MDT_2h to cur_MDT_2h + 2hrs
        start_MDT = cur_MDT_2h
        next_2hr_MDT = cur_MDT_2h + pd.DateOffset(hours=2)
        while(next_2hr_MDT <= next_MDT):            
            mask = ((cgmDataPat_['Date_Time'] > start_MDT) & (cgmDataPat_['Date_Time'] <= next_2hr_MDT))
            # get values of that mask added to cgmNMDataList
            mask_vals = np.array(cgmDataPat_.loc[mask]['Sensor Glucose (mg/dL)'])
            nonNALen = np.count_nonzero(~np.isnan(mask_vals))
            if (len(mask_vals)==24 and nonNALen >= (threshold/100)*24):
                cgmNMDataList.append(cgmDataPat_.loc[mask]['Sensor Glucose (mg/dL)'][::-1].tolist())
            # update vaues
            start_MDT = next_2hr_MDT
            next_2hr_MDT = next_2hr_MDT + pd.DateOffset(hours=2)
        
    # return the feature matrix
    return np.array(cgmNMDataList)

def feat_extr(data_mat):
    # variable to store list of lists (the inner list is list of 8 params)
    feat_mat_list = []
    # for each row create a list of 8 values (8 feature paramters)
    for idx, row in enumerate(data_mat):
        # create a list of 8 values/paramaeters
        feat_list = [None]*8

        # for each row consider minimum value index as tm value
        tm = np.nanargmin(row)

        # PARAMETER 1: difference between time at CGMMax and time at meal taken
        tau = np.nanargmax(row) - tm
        feat_list[0] = tau

        # PARAMETER 2: difference between CGMMax and CGM at time of meal taken
        CGMDiffNorm = (np.nanmax(row) - row[tm])/row[tm]
        feat_list[1] = CGMDiffNorm

        # PARAMETER 3,4,5,6: get FFT magnitude and frequency bins
        nonNARow = row[~np.isnan(row)]
        # fft
        fft_vals = np.fft.fft( nonNARow )
        # extract second and third peaks
        fft_vals_copy = fft_vals
        fft_vals_copy.sort()
        sec_max = fft_vals_copy[-2]
        thrd_max = fft_vals_copy[-3]
        # extract the indices of second and third peaks
        sec_max_ind = np.where(fft_vals==sec_max)[0][0]
        thrd_max_ind = np.where(fft_vals==thrd_max)[0][0]
        # add values to feat list
        feat_list[2] = abs(sec_max)
        feat_list[3] = sec_max_ind
        feat_list[4] = abs(thrd_max)
        feat_list[5] = thrd_max_ind

        # PARAMETER 7: differential of CGM data (GET MAX VALUE)
        feat_list[6] = np.nanmax(np.diff(row))

        # PARAMETER 8: double differential of CGM data        
        feat_list[7] = np.nanmax(np.diff(row, n=2))

        # add updated feature to feat_mat_list
        feat_mat_list.append(feat_list)

    return np.array(feat_mat_list)

def main():

    # assume CGMData.csv, CGM_patient2.csv and InsulinData.csv, Insulin_patient2.csv files are in compilation and execution folder
    # read data from the files - parse Date and Time columns as DateTime
    cgmDataPat_1_orig = pd.read_csv('CGMData.csv', parse_dates=[['Date', 'Time']])
    cgmDataPat_2_orig = pd.read_csv('CGM_patient2.csv', parse_dates=[['Date', 'Time']])
    insDataPat_1_orig = pd.read_csv('InsulinData.csv', parse_dates=[['Date', 'Time']])
    insDataPat_2_orig = pd.read_csv('Insulin_patient2.csv', parse_dates=[['Date', 'Time']])

    # STORE ORIG DATA IN VARIABLES (to be able to make changes and avoid reading csv everytime)
    # focus only on certain columns relevant to the dataset and Project 2
    cgmDataPat_1 = cgmDataPat_1_orig.loc[:, ['Date_Time', 'Sensor Glucose (mg/dL)']]
    cgmDataPat_2 = cgmDataPat_2_orig.loc[:, ['Date_Time', 'Sensor Glucose (mg/dL)']]
    insDataPat_1 = insDataPat_1_orig.loc[:, ['Date_Time', 'BWZ Carb Input (grams)']]
    insDataPat_2 = insDataPat_2_orig.loc[:, ['Date_Time', 'BWZ Carb Input (grams)']]

    #-------------------------------------------  MEAL DATA
    # run the extract_MD_DT function to get valid Date_Time values
    insValDT_1 = extractMDDT(insDataPat_1)
    insValDT_2 = extractMDDT(insDataPat_2)

    # SET THRESHOLD FOR NaN/MISSING/0 VALUES (in percentage)
    threshold = 80

    # get sensor values in cgmData for valid DTs
    mealDictPat_1 = getMDFeatMat(insValDT_1, cgmDataPat_1, threshold)
    mealDictPat_2 = getMDFeatMat(insValDT_2, cgmDataPat_2, threshold)

    # thus we get two matrices for two patients for MEAL DATA
    mat_MDPat_1 = mealDictPat_1['ft_mat']
    mat_MDPat_2 = mealDictPat_2['ft_mat']

    #----------------------------------------   NO MEAL DATA
    # valid Meal DateTimes that are present in the feature matrix
    # building on that we decide no-meal times
    cgmValDT_1 = mealDictPat_1['cgmValDT']
    cgmValDT_2 = mealDictPat_2['cgmValDT']

    mat_NMDPat_1 = getNMDFeatMat(cgmValDT_1, cgmDataPat_1, threshold)
    mat_NMDPat_2 = getNMDFeatMat(cgmValDT_2, cgmDataPat_2, threshold)

    #print("Matrices shape for each patient for MD")
    #print("Pat_1_MD:"+str(mat_MDPat_1.shape))
    #print("Pat_2_MD:"+str(mat_MDPat_2.shape))

    #print("Matrices shape for each patient for NMD")
    #print("Pat_1_NMD:"+str(mat_NMDPat_1.shape))
    #print("Pat_2_NMD:"+str(mat_NMDPat_2.shape))

    #-------------------------------------    FEATURE EXTRACTOR
    md_ft_1 = feat_extr(mat_MDPat_1)
    md_ft_2 = feat_extr(mat_MDPat_2)
    nmd_ft_1 = feat_extr(mat_NMDPat_1)
    nmd_ft_2 = feat_extr(mat_NMDPat_2)

    #print("FEAT Matrices shape for each patient for MD")
    #print("Pat_1_MD_Feat:"+str(md_ft_1.shape))
    #print("Pat_2_MD_Feat:"+str(md_ft_2.shape))

    #print("FEAT Matrices shape for each patient for NMD")
    #print("Pat_1_NMD_Feat:"+str(nmd_ft_1.shape))
    #print("Pat_2_NMD_Feat:"+str(nmd_ft_2.shape))

    # combine the matrices and add labels to make (P+Q)x(8+1) DATA MATRIX
    # merge all rows under md and nmd separately
    md_ft = np.row_stack( (md_ft_1, md_ft_2) )
    nmd_ft = np.row_stack( (nmd_ft_1, nmd_ft_2) )

    # merge all rows again for feature matrix (w/o labels)
    feature_mat = np.row_stack( (md_ft, nmd_ft) )

    # add class labels of 1 for md and 0 for nmd
    class_lbl_ones = np.ones( md_ft.shape[0] )
    class_lbl_zeros = np.zeros( nmd_ft.shape[0] )

    # total class labels
    class_lbls = np.row_stack( ( np.reshape(class_lbl_ones, (-1,1)), np.reshape(class_lbl_zeros, (-1, 1)) ) )

    # add a single column of class labels to the md and nmd matrix
    md_ft_lbls = np.column_stack( (md_ft, class_lbl_ones) )
    nmd_ft_lbls = np.column_stack( (nmd_ft, class_lbl_zeros) )

    # combine for FULL DATA MATRIX
    data_mat = np.column_stack( (feature_mat, class_lbls) )

    #print("MD Feat Labels shape:"+str(md_ft_lbls.shape))
    #print("NMD Feat Labels shape:"+str(nmd_ft_lbls.shape))
    #print("")
    #print("DATA MATRIX shape:"+str(data_mat.shape))

    #-------------------------------------    TRAINING SPLIT
    # shuffle both meal and no meal data
    #np.random.shuffle(md_ft_lbls)
    #np.random.shuffle(nmd_ft_lbls)
    # take 80% of meal data as train split
    md_len = md_ft_lbls.shape[0]
    md_len_80 = int(0.8*md_len)
    tr_md_ft_lbls = md_ft_lbls[:md_len_80, :]
    ts_md_ft_lbls = md_ft_lbls[:(md_len-md_len_80), :-1]
    tg_md_ft_lbls = md_ft_lbls[:(md_len-md_len_80), -1]

    # take 80% of no meal data as train split
    nmd_len = nmd_ft_lbls.shape[0]
    nmd_len_80 = int(0.8*nmd_len)
    tr_nmd_ft_lbls = nmd_ft_lbls[:nmd_len_80, :]
    ts_nmd_ft_lbls = nmd_ft_lbls[:(nmd_len-nmd_len_80), :-1]
    tg_nmd_ft_lbls = nmd_ft_lbls[:(nmd_len-nmd_len_80), -1]

    # combine md and nmd train data
    X_tr = np.row_stack( ( tr_md_ft_lbls[:, :-1], tr_nmd_ft_lbls[:, :-1] ) )
    y_tr = np.row_stack( ( np.reshape(tr_md_ft_lbls[:, -1], (-1,1)), np.reshape(tr_nmd_ft_lbls[:, -1], (-1,1)) ) )
    # combine md and nmd test data
    X_ts = np.row_stack( ( ts_md_ft_lbls, ts_nmd_ft_lbls ) )
    y_ts = np.row_stack( ( np.reshape(tg_md_ft_lbls, (-1,1)), np.reshape(tg_nmd_ft_lbls, (-1,1)) ) )

    #print("X_Train shape:"+str(X_tr.shape))
    #print("y_Train shape:"+str(y_tr.shape))
    #print("X_Test shape:"+str(X_ts.shape))
    #print("y_Test shape:"+str(y_ts.shape))

    #-------------------------------------    MODEL TRAINING (SVM)
    model = svm.NuSVC(gamma='auto')
    model.fit(X_tr, y_tr.ravel())
    # save the fitted model to pickle
    filename = 'NuSVC.pkl'
    pickle.dump(model, open(filename, 'wb'))

    print("MODEL SAVED IN NuSVC.sav!")
    pass

if __name__ == "__main__":
    main()